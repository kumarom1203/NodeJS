# chatbox
This is the chantbox a peer to peer chat application
User can send messages , images and files of any format 
